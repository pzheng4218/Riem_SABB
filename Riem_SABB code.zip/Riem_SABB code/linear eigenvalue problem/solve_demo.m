
n = 1000; k = 5;
A = randn(n); A = A'*A;
% A = diag(1:1000);
opts.mxitr = 3000;
opts.gtol = 1e-5;

X0 = randn(n,k);    X0 = orth(X0);

fprintf('method                obj            nrmGrad              itr             cpu           feasi \n')
tic; [X, Nerr0, out] = RSABB_BBQ(X0, @fun, opts, A); tsolve = toc;
out.fval = -2*out.fval; % convert the function value to the sum of eigenvalues
fprintf('RSABB_BBQ:       obj: %5.3e,  nrmGrad: %3.2e,  itr: %d,  cpu: %f,   norm(XT*X-I): %3.2e \n', out.fval, out.nrmGrad,  out.iter, tsolve, norm(X'*X - eye(k), 'fro'));


function [F, G] = fun(X,  A)
  G = -(A*X);
  F = 0.5*sum(dot(G,X,1));
end