

n = 500; k = 5; l = 1000;
A = randn(l,n); B = randn(l, k);
opts.mxitr = 3000;
opts.gtol = 1e-6;

X0 = randn(n,k);    X0 = orth(X0);

fprintf('method                obj            nrmGrad              itr             cpu           feasi \n')

tic; [X, Nerr0, out] = RSABB_BBQ(X0, @fun, opts, A, B); tsolve = toc;
fprintf('RSABB_BBQ:      obj: %5.3e,  nrmGrad: %3.2e,  itr: %d,  cpu: %6.4f,   norm(XT*X-I): %3.2e \n', out.fval, out.nrmGrad,  out.iter, tsolve, norm(X'*X - eye(k), 'fro'));


function [F, G] = fun(X, A, B)
  ATA_X = A' * A * X;
  ATB = A' * B;
  F = trace(X' * ATA_X - 2 * B' * A * X);
  G = 2 * ATA_X - 2 * ATB;
end