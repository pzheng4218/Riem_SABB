function [X, Nerr, out] = RSABB_BBQ(X0, fun, opts, A, B)



%% Size information
if isempty(X0)
    error('input X is an empty matrix');
else
    [~,~] = size(X0);
end

if isfield(opts, 'gtol')
    if opts.gtol < 0 || opts.gtol > 1
        opts.gtol = 1e-6;
    end
else
    opts.gtol = 1e-6;
end

% parameters for control the linear approximation in line search
if isfield(opts, 'mxitr')
    if opts.mxitr < 0 || opts.mxitr > 2^20
        opts.mxitr = 1000;
    end
else
    opts.mxitr = 1000;
end


if isfield(opts, 'gamma')
   if opts.gamma < 0 || opts.gamma > 10
        opts.gamma = 0.98;
   end
else
    opts.gamma = 0.98;
end


if isfield(opts, 'T')
   if opts.T < 0 || opts.T > 2^10
        opts.T = 1000;
   end
else
    opts.T = 1000;
end


if isfield(opts, 'gama')
   if opts.gama < 0 || opts.gama > 100
        opts.gama = 1.02;
   end
else
    opts.gama = 1.02;
end


if isfield(opts, 'tau')
   if opts.tau < 0 || opts.tau > 10
        opts.tau = 0.2;
   end
else
    opts.tau = 0.2;
end
%-------------------------------------------------------------------------------
% copy parameters
gtol   = opts.gtol;
gamma  = opts.gamma;
T      = opts.T;
mxitr  = opts.mxitr;
gama = opts.gama;
tau = opts.tau; 
alpha_min = 1e-10; alpha_max = 1; c = 1e-4;
iter = 0; lsn = 0; fen = 0; gen = 0;

mem_StY = zeros(2,1);


% prepare for iterations
[F0, G0] = feval(fun, X0, A, B); 
fen = fen + 1; gen = gen + 1;
XG_0 = X0'*G0;
Grad0 = G0 - 0.5*X0*(XG_0+XG_0');
err0 = norm(Grad0, 'fro');
Nerr = zeros(opts.mxitr,1); Nerr(1) = err0;

Z0 = -Grad0;

[Xk, Fk, Gk, fen_armijo] = GLL_line1(fun, X0, F0, Grad0, Z0, A, B);
lsn = lsn + 1;  
fen = fen + fen_armijo;  
gen = gen + 1;

XG_k = Xk'*Gk;
Gradk = Gk - 0.5*Xk*(XG_k+(XG_k)');
err = norm(Gradk, 'fro'); 
xnorm = norm(Xk, 'fro');
if (xnorm > 0.0)
    alphak_bb = xnorm /err;
else
    alphak_bb = 1.0/err;
end

%-------------------------------------------------------------------------------
start_time=tic(); 

while (err > gtol) && (iter < mxitr)

        alpha_bb = alphak_bb;
        
        Zk = -Gradk;
        Vk = Xk+alpha_bb*Zk;
        Kk = Vk' * Vk;
        Rk = chol(Kk,'upper');
        Xt = Vk / Rk;

        [Ft,Gt] = feval(fun, Xt, A, B); 
        fen = fen + 1; gen = gen + 1;
        delta = Ft - (Fk + c * alpha_bb * (err^2));
        pp = exp(-delta / T);
        
        if (pp <= rand(1))
            Zk = -Gradk; 
            [Xt, Ft, Gt, fen_armijo] = GLL_line2(fun, Xk, Fk, Gradk, Zk, A, B, alpha_bb); 
            lsn = lsn + 1; fen = fen + fen_armijo;

        end
        xnorm = norm(Xt, 'fro');
        XG_t = Xt' * Gt;
        Gradt = Gt - 0.5*Xt*(XG_t+XG_t');
        err = norm(Gradt, 'fro');
        Nerr(iter+1) = err;
        X0 = Xk; Xk = Xt; Fk = Ft; Grad0 = Gradk; Gradk = Gradt;
        
        
        Sk = Xk - X0; Yk = Gradk - Grad0;
        StY = sum(dot(Sk,Yk,1)); 
        
            if (StY > 0)
                mem_StY(mod(iter,2)+1) = 1;
                if (iter> 0 && mem_StY(mod(iter-1,2)+1)==1)
                    alphak_bb1_old = alphak_bb1;
                    alphak_bb2_old = alphak_bb2;
                end
                alphak_bb1 = sum(dot(Sk,Sk,1))/StY;
                alphak_bb2 = StY/sum(dot(Yk,Yk,1)); 

                if (alphak_bb2/alphak_bb1 < tau && sum(mem_StY) == 2)
                    phi13 = (alphak_bb2_old - alphak_bb2)/ (alphak_bb2_old * alphak_bb2 * (alphak_bb1_old - alphak_bb1));
                    phi23 = phi13 * alphak_bb1 + 1 / alphak_bb2;
                    alphak_bb_new = 2/( phi23 + sqrt(phi23^2 - 4*phi13) );
                    if ( alphak_bb_new <= 0 )
                        alphak_bb = min(alphak_bb2_old, alphak_bb2);
                    else
                        alphak_bb = min([alphak_bb_new, alphak_bb2, alphak_bb2_old]);
                    end
                    tau = tau/gama;
                else
                    alphak_bb = alphak_bb1;
                    tau = tau/gama;
                end
            else
                mem_StY = zeros(2,1);            
                alphak_bb = min(1.0/err, xnorm / err);
            end
            alphak_bb = max(alpha_min, min(alphak_bb, alpha_max));
            iter = iter+1;
            T = T * gamma;
end  
cput = toc(start_time); 

Nerr = Nerr(1:iter,1);


X = Xk;
out.time = cput;
out.fen = fen;
out.gen = gen;
out.fval = Fk;
out.nrmGrad = err;
out.lsn = lsn;
out.iter = iter;


end