function [Xt, Ft, Gt, m] = quad_GLL_line2(fun, Xk, Fk, Gradk, Zk, A, alpha_bb)

c1 = 1.0e-4; beta = 0.5;
prodGZk = sum(dot(Gradk,Zk,1));
Vk = Xk+alpha_bb*Zk;
Kk = Vk' *Vk;
Rk = chol(Kk,'upper');
Xt = Vk / Rk;
[Ft,Gt] = feval(fun, Xt, A); 
descent_k = c1*alpha_bb*prodGZk;
rhandk = Fk + descent_k;
m = 0;
while (m < 40) && (Ft > rhandk)
    m = m + 1;
    if ( alpha_bb <= 0.1)
        alpha_bb = beta * alpha_bb;
    else
        atemp = (-prodGZk*alpha_bb*alpha_bb)/(2.0*(Ft-Fk-alpha_bb*prodGZk));
        
        if ( atemp < 0.1 || atemp > (0.9*alpha_bb))
            atemp = beta * alpha_bb;
        end
        alpha_bb = atemp;
    end
    Vk = Xk+alpha_bb*Zk;
    Kk = Vk' *Vk;
    Rk = chol(Kk,'upper');
    Xt = Vk / Rk;
    [Ft, Gt] = feval(fun, Xt, A);
    descent_k = c1*alpha_bb*prodGZk;
    rhandk = Fk + descent_k;
end
end