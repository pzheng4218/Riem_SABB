
n = 500; % Number of rows/columns in A_j
p = 5; % Number of columns in X

loadData = load('therearray.mat');
A = loadData.A;

opts.mxitr = 3000;
opts.gtol = 1e-5;
opts.xtol = 1e-5;
opts.ftol = 1e-8;

X0 = randn(n, p);
X0 = orth(X0); % Ensure that X'X = I

fprintf('method                obj            nrmGrad              itr             cpu           feasi \n')

tic; [X, Nerr3, out] = RSABB_BBQ(X0, @fun, opts, A); tsolve = toc;
out.fval = out.fval; % convert the function value to the sum of eigenvalues
fprintf('RSABB_BBQ:     obj: %5.3e,  nrmGrad: %3.2e,  itr: %d,  cpu: %f,   norm(XT*X-I): %3.2e \n', out.fval, out.nrmGrad,  out.iter, tsolve, norm(X'*X - eye(p), 'fro'));


function [f, G] = fun(X, A)
    % X: n x p matrix, the variable we are optimizing over
    % A: n x n x N array, where each A(:,:,j) is a symmetric matrix

    [n, p] = size(X);  % Get the dimensions of X
    [n, n, p] = size(A);  % Dimensions of the 3D array A

    f = 0;
    G = zeros(n, p);

    for i = 1:p
        A_i = A(:, :, i); 
        f = f + X(:, i)' * A_i * X(:, i);
        G(:, i) = 2 * A_i * X(:, i);      
    end
end