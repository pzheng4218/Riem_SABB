function [Xt, Ft, Gt, m] = quad_GLL_line1(fun, Xk, Fk, Gradk, Zk, A)
alpha = 1.0;
c1 = 1.0e-4; beta = 0.5;
prodGZk = sum(dot(Gradk,Zk,1));
Vk = Xk+alpha*Zk;
Kk = Vk' * Vk;
Rk = chol(Kk,'upper');
Xt = Vk/ Rk;
[Ft,Gt] = feval(fun, Xt, A); 
descent_k = c1*alpha*prodGZk;
rhandk = Fk + descent_k;
m = 0;
while (m < 40) && (Ft > rhandk)
    m = m + 1;
    if ( alpha <= 0.1)
        alpha = beta * alpha;
    else
        atemp = (-prodGZk*alpha*alpha)/(2.0*(Ft-Fk-alpha*prodGZk));
        
        if ( atemp < 0.1 || atemp > (0.9*alpha))
            atemp = beta * alpha;
        end
        alpha = atemp;
    end
    Vk = Xk+alpha*Zk;
    Kk = Vk' * Vk;
    Rk = chol(Kk,'upper');
    Xt = Vk/ Rk;
    [Ft, Gt] = feval(fun, Xt, A);
    descent_k = c1*alpha*prodGZk;
    rhandk = Fk + descent_k;
end
end