n = 500; % Number of rows/columns in A_j
p = 5; % Number of columns in X

% Generate 3D array A
A = zeros(n, n, p);
for i = 1:p
    % Create B_j matrix
    B_i = randn(n); % B_j is n x n
    B_i = B_i + B_i'; % Make B_j symmetric

    % Create diagonal matrix elements
    diag_elements = sqrt(n + (1:n)); % Length should be n
    D_i = diag(diag_elements); % Create diagonal matrix

    % Ensure dimensions match
    A(:, :, i) = D_i + B_i; % Add diagonal and symmetric B_j
end
save('therearray.mat',"A");


